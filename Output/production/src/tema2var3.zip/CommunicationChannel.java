import java.util.concurrent.ArrayBlockingQueue;

/**
 * Class that implements the channel used by headquarters and space explorers to communicate.
 */
public class CommunicationChannel {

	ArrayBlockingQueue<Message> HQ2Explorer = new ArrayBlockingQueue<Message>(5000);
	ArrayBlockingQueue<Message> Explorer2HQ = new ArrayBlockingQueue<Message>(5000);
	/**
	 * Creates a {@code CommunicationChannel} object.
	 */
	public CommunicationChannel() {
	}

	/**
	 * Puts a message on the space explorer channel (i.e., where space explorers write to and 
	 * headquarters read from).
	 * 
	 * @param message
	 *            message to be put on the channel
	 */
	public synchronized void putMessageSpaceExplorerChannel(Message message) {
		try {
			Explorer2HQ.put(message);
		}
		catch(InterruptedException e)
		{
		}
	}

	/**
	 * Gets a message from the space explorer channel (i.e., where space explorers write to and
	 * headquarters read from).
	 * 
	 * @return message from the space explorer channel
	 */
	public Message getMessageSpaceExplorerChannel()
	{
		try {
			return Explorer2HQ.take();
		}
		catch(InterruptedException e)
		{
		}
		return null;
	}
	/**
	 * Puts a message on the headquarters channel (i.e., where headquarters write to and 
	 * space explorers read from).
	 * 
	 * @param message
	 *            message to be put on the channel
	 */
	public void putMessageHeadQuarterChannel(Message message) {
		try {
			HQ2Explorer.put(message);
		}
		catch(InterruptedException e)
		{
		}
	}

	/**
	 * Gets a message from the headquarters channel (i.e., where headquarters write to and
	 * space explorer read from).
	 * 
	 * @return message from the header quarter channel
	 */
	public synchronized Message getMessageHeadQuarterChannel() {
		try {
			return HQ2Explorer.take();
		}
		catch(InterruptedException e)
		{
		}
		return null;
	}
}
